import React from 'react'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ScrollArea } from "@/components/ui/scroll-area"

interface City {
  name: string
  rank: number
}

const ARIZONA_CITIES: City[] = [
  { rank: 1, name: "Phoenix" },
  { rank: 2, name: "Tucson" },
  { rank: 3, name: "Mesa" },
  { rank: 4, name: "Chandler" },
  { rank: 5, name: "Gilbert" },
  { rank: 6, name: "Glendale" },
  { rank: 7, name: "Scottsdale" },
  { rank: 8, name: "Peoria" },
  { rank: 9, name: "Tempe" },
  { rank: 10, name: "Surprise" },
  { rank: 11, name: "Goodyear" },
  { rank: 12, name: "Buckeye" },
  { rank: 13, name: "San Tan Valley" },
  { rank: 14, name: "Yuma" },
  { rank: 15, name: "Avondale" },
  { rank: 16, name: "Queen Creek" },
  { rank: 17, name: "Flagstaff" },
  { rank: 18, name: "Maricopa" },
  { rank: 19, name: "Casas Adobes" },
  { rank: 20, name: "Casa Grande" },
  { rank: 21, name: "Marana" },
  { rank: 22, name: "Lake Havasu City" },
  { rank: 23, name: "Prescott Valley" },
  { rank: 24, name: "Catalina Foothills" },
  { rank: 25, name: "Oro Valley" },
  { rank: 26, name: "Prescott" },
  { rank: 27, name: "Sierra Vista" },
  { rank: 28, name: "Bullhead City" },
  { rank: 29, name: "Apache Junction" },
  { rank: 30, name: "San Luis" },
  // ... Add all the remaining Arizona cities here
  { rank: 330, name: "Kaka" }
]

interface ArizonaCitySelectorProps {
  onCitySelect: (city: City) => void
  selectedCities: string[]
}

const ArizonaCitySelector: React.FC<ArizonaCitySelectorProps> = ({ onCitySelect, selectedCities }) => {
  return (
    <div className="space-y-2">
      <label htmlFor="city-select" className="block text-sm font-medium text-[#E4B649]">
        Select an Arizona City
      </label>
      <Select onValueChange={(value) => {
        const selectedCity = ARIZONA_CITIES.find(city => city.name === value)
        if (selectedCity) onCitySelect(selectedCity)
      }}>
        <SelectTrigger id="city-select" className="w-full bg-black/50 border-[#E4B649]/20 text-white">
          <SelectValue placeholder="Choose a city" />
        </SelectTrigger>
        <SelectContent className="bg-black border-[#E4B649]/20">
          <ScrollArea className="h-[200px]">
            {ARIZONA_CITIES.map((city) => (
              <SelectItem 
                key={city.rank} 
                value={city.name}
                className="text-white hover:bg-[#E4B649]/20"
                disabled={selectedCities.includes(city.name)}
              >
                {city.name}
              </SelectItem>
            ))}
          </ScrollArea>
        </SelectContent>
      </Select>
      <p className="text-xs text-[#E4B649]/70">
        * You can select up to 10 cities from Arizona
      </p>
    </div>
  )
}

export default ArizonaCitySelector

