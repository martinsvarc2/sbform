import React from 'react'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ScrollArea } from "@/components/ui/scroll-area"

interface City {
  name: string
  rank: number
}

const CALIFORNIA_CITIES: City[] = [
  { rank: 1, name: "Los Angeles" },
  { rank: 2, name: "San Diego" },
  { rank: 3, name: "San Jose" },
  { rank: 4, name: "San Francisco" },
  { rank: 5, name: "Fresno" },
  { rank: 6, name: "Sacramento" },
  { rank: 7, name: "Long Beach" },
  { rank: 8, name: "Oakland" },
  { rank: 9, name: "Bakersfield" },
  { rank: 10, name: "Anaheim" },
  { rank: 11, name: "Riverside" },
  { rank: 12, name: "Stockton" },
  { rank: 13, name: "Irvine" },
  { rank: 14, name: "Santa Ana" },
  { rank: 15, name: "Chula Vista" },
  { rank: 16, name: "Fremont" },
  { rank: 17, name: "San Bernardino" },
  { rank: 18, name: "Santa Clarita" },
  { rank: 19, name: "Modesto" },
  { rank: 20, name: "Fontana" },
  { rank: 21, name: "Moreno Valley" },
  { rank: 22, name: "Oxnard" },
  { rank: 23, name: "Huntington Beach" },
  { rank: 24, name: "Ontario" },
  { rank: 25, name: "Glendale" },
  { rank: 26, name: "Elk Grove" },
  { rank: 27, name: "Santa Rosa" },
  { rank: 28, name: "Rancho Cucamonga" },
  { rank: 29, name: "Oceanside" },
  { rank: 30, name: "Garden Grove" },
  { rank: 31, name: "Lancaster" },
  { rank: 32, name: "Roseville" },
  { rank: 33, name: "Corona" },
  { rank: 34, name: "Palmdale" },
  { rank: 35, name: "Salinas" },
  { rank: 36, name: "Hayward" },
  { rank: 37, name: "Sunnyvale" },
  { rank: 38, name: "Escondido" },
  { rank: 39, name: "Visalia" },
  { rank: 40, name: "Pomona" },
  { rank: 41, name: "Victorville" },
  { rank: 42, name: "Orange" },
  { rank: 43, name: "Fullerton" },
  { rank: 44, name: "Torrance" },
  { rank: 45, name: "Pasadena" },
  { rank: 46, name: "Santa Clara" },
  { rank: 47, name: "Clovis" },
  { rank: 48, name: "Simi Valley" },
  { rank: 49, name: "Thousand Oaks" },
  { rank: 50, name: "Vallejo" },
  // ... Add all other cities from the list
]

interface CaliforniaCitySelectorProps {
  onCitySelect: (city: City) => void
  selectedCities: string[]
}

const CaliforniaCitySelector: React.FC<CaliforniaCitySelectorProps> = ({ onCitySelect, selectedCities }) => {
  return (
    <div className="space-y-2">
      <label htmlFor="city-select" className="block text-sm font-medium text-[#E4B649]">
        Select a California City
      </label>
      <Select onValueChange={(value) => {
        const selectedCity = CALIFORNIA_CITIES.find(city => city.name === value)
        if (selectedCity) onCitySelect(selectedCity)
      }}>
        <SelectTrigger id="city-select" className="w-full bg-black/50 border-[#E4B649]/20 text-white">
          <SelectValue placeholder="Choose a city" />
        </SelectTrigger>
        <SelectContent className="bg-black border-[#E4B649]/20">
          <ScrollArea className="h-[200px]">
            {CALIFORNIA_CITIES.map((city) => (
              <SelectItem 
                key={city.rank} 
                value={city.name}
                className="text-white hover:bg-[#E4B649]/20"
                disabled={selectedCities.includes(city.name)}
              >
                {city.name}
              </SelectItem>
            ))}
          </ScrollArea>
        </SelectContent>
      </Select>
      <p className="text-xs text-[#E4B649]/70">
        * You can select up to 10 cities from California
      </p>
    </div>
  )
}

export default CaliforniaCitySelector

