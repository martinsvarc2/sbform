import React from 'react'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ScrollArea } from "@/components/ui/scroll-area"

interface City {
  name: string
  rank: number
}

const FLORIDA_CITIES: City[] = [
  { rank: 1, name: "Jacksonville" },
  { rank: 2, name: "Miami" },
  { rank: 3, name: "Tampa" },
  { rank: 4, name: "Orlando" },
  { rank: 5, name: "St. Petersburg" },
  { rank: 6, name: "Hialeah" },
  { rank: 7, name: "Port St. Lucie" },
  { rank: 8, name: "Cape Coral" },
  { rank: 9, name: "Tallahassee" },
  { rank: 10, name: "Fort Lauderdale" },
  { rank: 11, name: "Pembroke Pines" },
  { rank: 12, name: "Hollywood" },
  { rank: 13, name: "Miramar" },
  { rank: 14, name: "Gainesville" },
  { rank: 15, name: "Coral Springs" },
  { rank: 16, name: "Miami Gardens" },
  { rank: 17, name: "Clearwater" },
  { rank: 18, name: "Palm Bay" },
  { rank: 19, name: "Pompano Beach" },
  { rank: 20, name: "West Palm Beach" },
  { rank: 21, name: "Lakeland" },
  { rank: 22, name: "Davie" },
  { rank: 23, name: "Miami Beach" },
  { rank: 24, name: "Sunrise" },
  { rank: 25, name: "Plantation" },
  { rank: 26, name: "Boca Raton" },
  { rank: 27, name: "Deltona" },
  { rank: 28, name: "Palm Coast" },
  { rank: 29, name: "Largo" },
  { rank: 30, name: "Deerfield Beach" },
  { rank: 31, name: "Melbourne" },
  { rank: 32, name: "Boynton Beach" },
  { rank: 33, name: "Fort Myers" },
  { rank: 34, name: "Lauderhill" },
  { rank: 35, name: "Weston" },
  { rank: 36, name: "Kissimmee" },
  { rank: 37, name: "Homestead" },
  { rank: 38, name: "Delray Beach" },
  { rank: 39, name: "Tamarac" },
  { rank: 40, name: "Daytona Beach" },
  { rank: 41, name: "North Port" },
  { rank: 42, name: "Wellington" },
  { rank: 43, name: "North Miami" },
  { rank: 44, name: "Jupiter" },
  { rank: 45, name: "Port Orange" },
  { rank: 46, name: "Port St. Lucie" },
  { rank: 47, name: "Coconut Creek" },
  { rank: 48, name: "Sanford" },
  { rank: 49, name: "Margate" },
  { rank: 50, name: "Ocala" },
  // Add more cities as needed
];

interface FloridaCitySelectorProps {
  onCitySelect: (city: City) => void
  selectedCities: string[]
}

const FloridaCitySelector: React.FC<FloridaCitySelectorProps> = ({ onCitySelect, selectedCities }) => {
  return (
    <div className="space-y-2">
      <label htmlFor="city-select" className="block text-sm font-medium text-[#E4B649]">
        Select a Florida City
      </label>
      <Select onValueChange={(value) => {
        const selectedCity = FLORIDA_CITIES.find(city => city.name === value)
        if (selectedCity) onCitySelect(selectedCity)
      }}>
        <SelectTrigger id="city-select" className="w-full bg-black/50 border-[#E4B649]/20 text-white">
          <SelectValue placeholder="Choose a city" />
        </SelectTrigger>
        <SelectContent className="bg-black border-[#E4B649]/20">
          <ScrollArea className="h-[200px]">
            {FLORIDA_CITIES.map((city) => (
              <SelectItem 
                key={city.rank} 
                value={city.name}
                className="text-white hover:bg-[#E4B649]/20"
                disabled={selectedCities.includes(city.name)}
              >
                {city.name}
              </SelectItem>
            ))}
          </ScrollArea>
        </SelectContent>
      </Select>
      <p className="text-xs text-[#E4B649]/70">
        * You can select up to 10 cities from Florida
      </p>
    </div>
  )
}

export default FloridaCitySelector

