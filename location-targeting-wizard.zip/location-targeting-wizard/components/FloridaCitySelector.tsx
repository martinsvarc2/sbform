import React from 'react'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ScrollArea } from "@/components/ui/scroll-area"

interface City {
  name: string
  rank: number
}

const FLORIDA_CITIES: City[] = [
  { rank: 1, name: "Jacksonville" },
  { rank: 2, name: "Miami" },
  { rank: 3, name: "Tampa" },
  { rank: 4, name: "Orlando" },
  { rank: 5, name: "St. Petersburg" },
  { rank: 6, name: "Port St. Lucie" },
  { rank: 7, name: "Cape Coral" },
  { rank: 8, name: "Hialeah" },
  { rank: 9, name: "Tallahassee" },
  { rank: 10, name: "Fort Lauderdale" },
  { rank: 11, name: "Pembroke Pines" },
  { rank: 12, name: "Hollywood" },
  { rank: 13, name: "Gainesville" },
  { rank: 14, name: "Palm Bay" },
  { rank: 15, name: "Miramar" },
  { rank: 16, name: "Coral Springs" },
  { rank: 17, name: "Lehigh Acres" },
  { rank: 18, name: "West Palm Beach" },
  { rank: 19, name: "Lakeland" },
  { rank: 20, name: "Spring Hill" },
  // ... Add all the cities from the provided list
  { rank: 400, name: "Orangetree" },
  { rank: 401, name: "Timber Pines" }
]

interface FloridaCitySelectorProps {
  onCitySelect: (city: City) => void
  selectedCities: string[]
}

const FloridaCitySelector: React.FC<FloridaCitySelectorProps> = ({ onCitySelect, selectedCities }) => {
  return (
    <div className="space-y-2">
      <label htmlFor="city-select" className="block text-sm font-medium text-[#E4B649]">
        Select a Florida City
      </label>
      <Select onValueChange={(value) => {
        const selectedCity = FLORIDA_CITIES.find(city => city.name === value)
        if (selectedCity) onCitySelect(selectedCity)
      }}>
        <SelectTrigger id="city-select" className="w-full bg-black/50 border-[#E4B649]/20 text-white">
          <SelectValue placeholder="Choose a city" />
        </SelectTrigger>
        <SelectContent className="bg-black border-[#E4B649]/20">
          <ScrollArea className="h-[200px]">
            {FLORIDA_CITIES.map((city) => (
              <SelectItem 
                key={city.rank} 
                value={city.name}
                className="text-white hover:bg-[#E4B649]/20"
                disabled={selectedCities.includes(city.name)}
              >
                {city.name}
              </SelectItem>
            ))}
          </ScrollArea>
        </SelectContent>
      </Select>
      <p className="text-xs text-[#E4B649]/70">
        * You can select up to 10 cities from Florida
      </p>
    </div>
  )
}

export default FloridaCitySelector

