import React from 'react'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ScrollArea } from "@/components/ui/scroll-area"

interface City {
  name: string
  rank: number
}

const ALABAMA_CITIES: City[] = [
  { rank: 1, name: "Huntsville" },
  { rank: 2, name: "Birmingham" },
  { rank: 3, name: "Montgomery" },
  { rank: 4, name: "Mobile" },
  { rank: 5, name: "Tuscaloosa" },
  { rank: 6, name: "Hoover" },
  { rank: 7, name: "Auburn" },
  { rank: 8, name: "Dothan" },
  { rank: 9, name: "Madison" },
  { rank: 10, name: "Decatur" },
  { rank: 11, name: "Florence" },
  { rank: 12, name: "Prattville" },
  { rank: 13, name: "Phenix City" },
  { rank: 14, name: "Vestavia Hills" },
  { rank: 15, name: "Opelika" },
  { rank: 16, name: "Alabaster" },
  { rank: 17, name: "Gadsden" },
  { rank: 18, name: "Athens" },
  { rank: 19, name: "Daphne" },
  { rank: 20, name: "Northport" },
  { rank: 21, name: "Enterprise" },
  { rank: 22, name: "Homewood" },
  { rank: 23, name: "Trussville" },
  { rank: 24, name: "Foley" },
  { rank: 25, name: "Fairhope" },
  { rank: 26, name: "Pelham" },
  { rank: 27, name: "Bessemer" },
  { rank: 28, name: "Albertville" },
  { rank: 29, name: "Helena" },
  { rank: 30, name: "Oxford" },
  // Add all remaining cities...
  { rank: 587, name: "Movico" }
]

interface AlabamaCitySelectorProps {
  onCitySelect: (city: City) => void
  selectedCities: string[]
}

const AlabamaCitySelector: React.FC<AlabamaCitySelectorProps> = ({ onCitySelect, selectedCities }) => {
  return (
    <div className="space-y-2">
      <label htmlFor="city-select" className="block text-sm font-medium text-[#E4B649]">
        Select an Alabama City
      </label>
      <Select onValueChange={(value) => {
        const selectedCity = ALABAMA_CITIES.find(city => city.name === value)
        if (selectedCity) onCitySelect(selectedCity)
      }}>
        <SelectTrigger id="city-select" className="w-full bg-black/50 border-[#E4B649]/20 text-white">
          <SelectValue placeholder="Choose a city" />
        </SelectTrigger>
        <SelectContent className="bg-black border-[#E4B649]/20">
          <ScrollArea className="h-[200px]">
            {ALABAMA_CITIES.map((city) => (
              <SelectItem 
                key={city.rank} 
                value={city.name}
                className="text-white hover:bg-[#E4B649]/20"
                disabled={selectedCities.includes(city.name)}
              >
                {city.name}
              </SelectItem>
            ))}
          </ScrollArea>
        </SelectContent>
      </Select>
      <p className="text-xs text-[#E4B649]/70">
        * You can select up to 10 cities from Alabama
      </p>
    </div>
  )
}

export default AlabamaCitySelector

