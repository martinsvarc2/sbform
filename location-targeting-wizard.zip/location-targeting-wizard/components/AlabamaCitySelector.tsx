import React from 'react'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface City {
  rank: number
  name: string
  population: number
  previousPopulation: number
  landArea: number
  density: number
  changePercentage: number
  type: string
}

const ALABAMA_CITIES: City[] = [
  { rank: 1, name: "Huntsville", population: 228616, previousPopulation: 222030, landArea: 1022, density: 223.6, changePercentage: 1.35, type: "City" },
  { rank: 2, name: "Birmingham", population: 195400, previousPopulation: 196887, landArea: 1329, density: 147.1, changePercentage: -0.63, type: "City" },
  { rank: 3, name: "Montgomery", population: 193702, previousPopulation: 196944, landArea: 1212, density: 159.9, changePercentage: -0.81, type: "City" },
  { rank: 4, name: "Mobile", population: 181253, previousPopulation: 183290, landArea: 1299, density: 139.5, changePercentage: -0.73, type: "City" },
  { rank: 5, name: "Tuscaloosa", population: 113711, previousPopulation: 110575, landArea: 1830, density: 62.1, changePercentage: 2.13, type: "City" },
  // ... Add more cities as needed
]

interface AlabamaCitySelectorProps {
  onCitySelect: (city: City) => void
  selectedCities: string[]
}

const AlabamaCitySelector: React.FC<AlabamaCitySelectorProps> = ({ onCitySelect, selectedCities }) => {
  return (
    <div className="space-y-2">
      <label htmlFor="city-select" className="block text-sm font-medium text-gray-700">
        Select an Alabama City
      </label>
      <Select onValueChange={(value) => {
        const selectedCity = ALABAMA_CITIES.find(city => city.name === value)
        if (selectedCity) onCitySelect(selectedCity)
      }}>
        <SelectTrigger id="city-select" className="w-full">
          <SelectValue placeholder="Choose a city" />
        </SelectTrigger>
        <SelectContent>
          {ALABAMA_CITIES.map((city) => (
            <SelectItem 
              key={city.rank} 
              value={city.name}
              disabled={selectedCities.includes(city.name)}
            >
              {city.name} (Pop: {city.population.toLocaleString()})
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  )
}

export default AlabamaCitySelector

