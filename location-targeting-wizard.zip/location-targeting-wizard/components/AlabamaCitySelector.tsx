import React from 'react'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface City {
  rank: number
  name: string
  population: number
  previousPopulation?: number // Made optional
  landArea?: number // Made optional
  density?: number // Made optional
  changePercentage?: number // Made optional
  type: string
}

const ALABAMA_CITIES: City[] = [
  { rank: 1, name: "Huntsville", population: 228616, type: "City" },
  { rank: 2, name: "Birmingham", population: 195400, type: "City" },
  { rank: 3, name: "Montgomery", population: 193702, type: "City" },
  { rank: 4, name: "Mobile", population: 181253, type: "City" },
  { rank: 5, name: "Tuscaloosa", population: 113711, type: "City" },
  // ... Add all cities from the list
  { rank: 587, name: "Movico", population: 0, type: "CDP" }
];

interface AlabamaCitySelectorProps {
  onCitySelect: (city: City) => void
  selectedCities: string[]
}

const AlabamaCitySelector: React.FC<AlabamaCitySelectorProps> = ({ onCitySelect, selectedCities }) => {
  return (
    <div className="space-y-2">
      <label htmlFor="city-select" className="block text-sm font-medium text-gray-700">
        Select an Alabama City
      </label>
      <Select onValueChange={(value) => {
        const selectedCity = ALABAMA_CITIES.find(city => city.name === value)
        if (selectedCity) onCitySelect(selectedCity)
      }}>
        <SelectTrigger id="city-select" className="w-full">
          <SelectValue placeholder="Choose a city" />
        </SelectTrigger>
        <SelectContent>
          {ALABAMA_CITIES.map((city) => (
            <SelectItem 
              key={city.rank} 
              value={city.name}
              disabled={selectedCities.includes(city.name)}
            >
              {city.name}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  )
}

export default AlabamaCitySelector

