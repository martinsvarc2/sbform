import React from 'react'
import { cn } from "@/lib/utils"

interface USAMapProps {
  className?: string
  selectedStates: string[]
  onStateClick: (state: string) => void
}

const USAMap: React.FC<USAMapProps> = ({ className, selectedStates, onStateClick }) => {
  const stateColors = {
    default: '#000000', // Black fill
    selected: '#E4B649', // Gold color for selected states
    hover: '#1F2937', // Slightly lighter for hover
    stroke: '#E4B649', // Gold border color
  }

  const getStateColor = (stateName: string) => {
    if (selectedStates.includes(stateName)) {
      return stateColors.selected
    }
    return stateColors.default
  }

  return (
    <div className="relative w-full">
      <svg
        viewBox="0 0 1000 600"
        className={cn("w-full h-auto", className)}
        role="img"
        aria-label="United States Map"
      >
        <title>United States Map</title>
        <g>
          {/* Continental US */}
          <path d="M 130.5 359.5 L 133.5 359.5 L 133.5 361.5 L 130.5 361.5 Z" fill={getStateColor('Washington')} stroke={stateColors.stroke} strokeWidth="1" onClick={() => onStateClick('Washington')} />
          <path d="M 138.5 365.5 L 140.5 365.5 L 140.5 367.5 L 138.5 367.5 Z" fill={getStateColor('Oregon')} stroke={stateColors.stroke} strokeWidth="1" onClick={() => onStateClick('Oregon')} />
          <path d="M 144.5 379.5 L 146.5 379.5 L 146.5 381.5 L 144.5 381.5 Z" fill={getStateColor('California')} stroke={stateColors.stroke} strokeWidth="1" onClick={() => onStateClick('California')} />
          <path d="M 196.5 379.5 L 198.5 379.5 L 198.5 381.5 L 196.5 381.5 Z" fill={getStateColor('Nevada')} stroke={stateColors.stroke} strokeWidth="1" onClick={() => onStateClick('Nevada')} />
          <path d="M 233.5 383.5 L 235.5 383.5 L 235.5 385.5 L 233.5 385.5 Z" fill={getStateColor('Arizona')} stroke={stateColors.stroke} strokeWidth="1" onClick={() => onStateClick('Arizona')} />
          <path d="M 247.5 365.5 L 249.5 365.5 L 249.5 367.5 L 247.5 367.5 Z" fill={getStateColor('Utah')} stroke={stateColors.stroke} strokeWidth="1" onClick={() => onStateClick('Utah')} />
          <path d="M 255.5 349.5 L 257.5 349.5 L 257.5 351.5 L 255.5 351.5 Z" fill={getStateColor('Idaho')} stroke={stateColors.stroke} strokeWidth="1" onClick={() => onStateClick('Idaho')} />
          <path d="M 267.5 333.5 L 269.5 333.5 L 269.5 335.5 L 267.5 335.5 Z" fill={getStateColor('Montana')} stroke={stateColors.stroke} strokeWidth="1" onClick={() => onStateClick('Montana')} />
          <path d="M 303.5 349.5 L 305.5 349.5 L 305.5 351.5 L 303.5 351.5 Z" fill={getStateColor('Wyoming')} stroke={stateColors.stroke} strokeWidth="1" onClick={() => onStateClick('Wyoming')} />
          <path d="M 303.5 379.5 L 305.5 379.5 L 305.5 381.5 L 303.5 381.5 Z" fill={getStateColor('Colorado')} stroke={stateColors.stroke} strokeWidth="1" onClick={() => onStateClick('Colorado')} />
          <path d="M 303.5 409.5 L 305.5 409.5 L 305.5 411.5 L 303.5 411.5 Z" fill={getStateColor('New Mexico')} stroke={stateColors.stroke} strokeWidth="1" onClick={() => onStateClick('New Mexico')} />
          <path d="M 339.5 409.5 L 341.5 409.5 L 341.5 411.5 L 339.5 411.5 Z" fill={getStateColor('Texas')} stroke={stateColors.stroke} strokeWidth="1" onClick={() => onStateClick('Texas')} />
          <path d="M 339.5 379.5 L 341.5 379.5 L 341.5 381.5 L 339.5 381.5 Z" fill={getStateColor('Oklahoma')} stroke={stateColors.stroke} strokeWidth="1" onClick={() => onStateClick('Oklahoma')} />
          <path d="M 339.5 349.5 L 341.5 349.5 L 341.5 351.5 L 339.5 351.5 Z" fill={getStateColor('Kansas')} stroke={stateColors.stroke} strokeWidth="1" onClick={() => onStateClick('Kansas')} />
          <path d="M 339.5 319.5 L 341.5 319.5 L 341.5 321.5 L 339.5 321.5 Z" fill={getStateColor('Nebraska')} stroke={stateColors.stroke} strokeWidth="1" onClick={() => onStateClick('Nebraska')} />
          <path d="M 339.5 289.5 L 341.5 289.5 L 341.5 291.5 L 339.5 291.5 Z" fill={getStateColor('South Dakota')} stroke={stateColors.stroke} strokeWidth="1" onClick={() => onStateClick('South Dakota')} />
          <path d="M 339.5 259.5 L 341.5 259.5 L 341.5 261.5 L 339.5 261.5 Z" fill={getStateColor('North Dakota')} stroke={stateColors.stroke} strokeWidth="1" onClick={() => onStateClick('North Dakota')} />
          <path d="M 375.5 289.5 L 377.5 289.5 L 377.5 291.5 L 375.5 291.5 Z" fill={getStateColor('Minnesota')} stroke={stateColors.stroke} strokeWidth="1" onClick={() => onStateClick('Minnesota')} />
          <path d="M 411.5 319.5 L 413.5 319.5 L 413.5 321.5 L 411.5 321.5 Z" fill={getStateColor('Iowa')} stroke={stateColors.stroke} strokeWidth="1" onClick={() => onStateClick('Iowa')} />
          <path d="M 411.5 349.5 L 413.5 349.5 L 413.5 351.5 L 411.5 351.5 Z" fill={getStateColor('Missouri')} stroke={stateColors.stroke} strokeWidth="1" onClick={() => onStateClick('Missouri')} />
          <path d="M 411.5 379.5 L 413.5 379.5 L 413.5 381.5 L 411.5 381.5 Z" fill={getStateColor('Arkansas')} stroke={stateColors.stroke} strokeWidth="1" onClick={() => onStateClick('Arkansas')} />
          <path d="M 411.5 409.5 L 413.5 409.5 L 413.5 411.5 L 411.5 411.5 Z" fill={getStateColor('Louisiana')} stroke={stateColors.stroke} strokeWidth="1" onClick={() => onStateClick('Louisiana')} />
          <path d="M 447.5 409.5 L 449.5 409.5 L 449.5 411.5 L 447.5 411.5 Z" fill={getStateColor('Mississippi')} stroke={stateColors.stroke} strokeWidth="1" onClick={() => onStateClick('Mississippi')} />
          <path d="M 483.5 409.5 L 485.5 409.5 L 485.5 411.5 L 483.5 411.5 Z" fill={getStateColor('Alabama')} stroke={stateColors.stroke} strokeWidth="1" onClick={() => onStateClick('Alabama')} />
          <path d="M 519.5 409.5 L 521.5 409.5 L 521.5 411.5 L 519.5 411.5 Z" fill={getStateColor('Georgia')} stroke={stateColors.stroke} strokeWidth="1" onClick={() => onStateClick('Georgia')} />
          <path d="M 555.5 409.5 L 557.5 409.5 L 557.5 411.5 L 555.5 411.5 Z" fill={getStateColor('South Carolina')} stroke={stateColors.stroke} strokeWidth="1" onClick={() => onStateClick('South Carolina')} />
          <path d="M 555.5 379.5 L 557.5 379.5 L 557.5 381.5 L 555.5 381.5 Z" fill={getStateColor('North Carolina')} stroke={stateColors.stroke} strokeWidth="1" onClick={() => onStateClick('North Carolina')} />
          <path d="M 555.5 349.5 L 557.5 349.5 L 557.5 351.5 L 555.5 351.5 Z" fill={getStateColor('Virginia')} stroke={stateColors.stroke} strokeWidth="1" onClick={() => onStateClick('Virginia')} />
          <path d="M 555.5 319.5 L 557.5 319.5 L 557.5 321.5 L 555.5 321.5 Z" fill={getStateColor('West Virginia')} stroke={stateColors.stroke} strokeWidth="1" onClick={() => onStateClick('West Virginia')} />
          <path d="M 591.5 319.5 L 593.5 319.5 L 593.5 321.5 L 591.5 321.5 Z" fill={getStateColor('Maryland')} stroke={stateColors.stroke} strokeWidth="1" onClick={() => onStateClick('Maryland')} />
          <path d="M 627.5 319.5 L 629.5 319.5 L 629.5 321.5 L 627.5 321.5 Z" fill={getStateColor('Delaware')} stroke={stateColors.stroke} strokeWidth="1" onClick={() => onStateClick('Delaware')} />
          <path d="M 627.5 289.5 L 629.5 289.5 L 629.5 291.5 L 627.5 291.5 Z" fill={getStateColor('New Jersey')} stroke={stateColors.stroke} strokeWidth="1" onClick={() => onStateClick('New Jersey')} />
          <path d="M 627.5 259.5 L 629.5 259.5 L 629.5 261.5 L 627.5 261.5 Z" fill={getStateColor('New York')} stroke={stateColors.stroke} strokeWidth="1" onClick={() => onStateClick('New York')} />
          <path d="M 663.5 259.5 L 665.5 259.5 L 665.5 261.5 L 663.5 261.5 Z" fill={getStateColor('Connecticut')} stroke={stateColors.stroke} strokeWidth="1" onClick={() => onStateClick('Connecticut')} />
          <path d="M 663.5 229.5 L 665.5 229.5 L 665.5 231.5 L 663.5 231.5 Z" fill={getStateColor('Massachusetts')} stroke={stateColors.stroke} strokeWidth="1" onClick={() => onStateClick('Massachusetts')} />
          <path d="M 699.5 229.5 L 701.5 229.5 L 701.5 231.5 L 699.5 231.5 Z" fill={getStateColor('Rhode Island')} stroke={stateColors.stroke} strokeWidth="1" onClick={() => onStateClick('Rhode Island')} />
          <path d="M 699.5 199.5 L 701.5 199.5 L 701.5 201.5 L 699.5 201.5 Z" fill={getStateColor('New Hampshire')} stroke={stateColors.stroke} strokeWidth="1" onClick={() => onStateClick('New Hampshire')} />
          <path d="M 699.5 169.5 L 701.5 169.5 L 701.5 171.5 L 699.5 171.5 Z" fill={getStateColor('Maine')} stroke={stateColors.stroke} strokeWidth="1" onClick={() => onStateClick('Maine')} />
          <path d="M 663.5 199.5 L 665.5 199.5 L 665.5 201.5 L 663.5 201.5 Z" fill={getStateColor('Vermont')} stroke={stateColors.stroke} strokeWidth="1" onClick={() => onStateClick('Vermont')} />
          
          {/* Alaska */}
          <path d="M 130.5 459.5 L 190.5 459.5 L 190.5 489.5 L 130.5 489.5 Z" fill={getStateColor('Alaska')} stroke={stateColors.stroke} strokeWidth="1" onClick={() => onStateClick('Alaska')} />
          
          {/* Hawaii */}
          <path d="M 130.5 499.5 L 190.5 499.5 L 190.5 529.5 L 130.5 529.5 Z" fill={getStateColor('Hawaii')} stroke={stateColors.stroke} strokeWidth="1" onClick={() => onStateClick('Hawaii')} />
        </g>
      </svg>
    </div>
  )
}

export default USAMap

