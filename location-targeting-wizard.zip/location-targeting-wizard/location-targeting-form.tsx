import { useState } from 'react';
import { Select, Checkbox } from '@nextui-org/react';

const US_STATES = [
  'Alabama', 'Alaska', 'Arizona', 'Arkansas', 'California', 'Colorado', 'Connecticut',
  'Delaware', 'Florida', 'Georgia', 'Hawaii', 'Idaho', 'Illinois', 'Indiana', 'Iowa',
  'Kansas', 'Kentucky', 'Louisiana', 'Maine', 'Maryland', 'Massachusetts', 'Michigan',
  'Minnesota', 'Mississippi', 'Missouri', 'Montana', 'Nebraska', 'Nevada', 'New Hampshire',
  'New Jersey', 'New Mexico', 'New York', 'North Carolina', 'North Dakota', 'Ohio', 'Oklahoma',
  'Oregon', 'Pennsylvania', 'Rhode Island', 'South Carolina', 'South Dakota', 'Tennessee',
  'Texas', 'Utah', 'Vermont', 'Virginia', 'Washington', 'West Virginia', 'Wisconsin', 'Wyoming',
];

const MOCK_CITIES = {}; // Removed mock city generation


const App = () => {
  const [selectedState, setSelectedState] = useState('');
  const [selectedCities, setSelectedCities] = useState([]);

  const handleStateChange = (state) => {
    setSelectedState(state);
    setSelectedCities([]); // Reset cities when state changes
  };

  const handleCityChange = (city) => {
    const updatedCities = selectedCities.includes(city)
      ? selectedCities.filter((c) => c !== city)
      : [...selectedCities, city];
    setSelectedCities(updatedCities);
  };

  const availableCities = selectedState ? (selectedState in MOCK_CITIES ? MOCK_CITIES[selectedState] : []) : [];

  const isCitySelected = (city) => selectedCities.includes(city);

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-2xl font-bold mb-4">City Selector</h1>
      <Select
        label="Select State"
        onChange={(e) => handleStateChange(e.target.value)}
        value={selectedState}
      >
        {US_STATES.map((state) => (
          <Select.Option key={state} value={state}>
            {state}
          </Select.Option>
        ))}
      </Select>

      {selectedState && (
        <div className="mt-4">
          <p className="text-lg font-medium mb-2">Select Cities:</p>
          {availableCities.map((city) => (
            <div key={city} className="flex items-center mb-1">
              <Checkbox
                checked={isCitySelected(city)}
                onChange={() => handleCityChange(city)}
              />
              <span className="ml-2">{city}</span>
            </div>
          ))}
          <p className="text-sm text-muted-foreground mt-1">
            * You can select up to 10 cities from the largest cities when exactly one state is selected.
          </p>
        </div>
      )}
    </div>
  );
};

export default App;

