"use client"

import { useState } from "react"
import { Check, X } from 'lucide-react'
import { Card } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Checkbox } from "@/components/ui/checkbox"
import { Textarea } from "@/components/ui/textarea"
import { Button } from "@/components/ui/button"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { FormState, LocationFormProps, TargetingType } from "./types/form"

const US_STATES = [
  "Alabama", "Alaska", "Arizona", "Arkansas", "California",
  "Colorado", "Connecticut", "Delaware", "Florida", "Georgia",
  "Hawaii", "Idaho", "Illinois", "Indiana", "Iowa",
  "Kansas", "Kentucky", "Louisiana", "Maine", "Maryland",
  "Massachusetts", "Michigan", "Minnesota", "Mississippi", "Missouri",
  "Montana", "Nebraska", "Nevada", "New Hampshire", "New Jersey",
  "New Mexico", "New York", "North Carolina", "North Dakota", "Ohio",
  "Oklahoma", "Oregon", "Pennsylvania", "Rhode Island", "South Carolina",
  "South Dakota", "Tennessee", "Texas", "Utah", "Vermont",
  "Virginia", "Washington", "West Virginia", "Wisconsin", "Wyoming"
]

const MOCK_CITIES: { [key: string]: string[] } = {
  "California": ["Los Angeles", "San Francisco", "San Diego", "San Jose", "Fresno"],
  "New York": ["New York City", "Buffalo", "Rochester", "Yonkers", "Syracuse"],
  "Texas": ["Houston", "San Antonio", "Dallas", "Austin", "Fort Worth"],
}

export default function LocationTargetingForm({ onSubmit }: LocationFormProps) {
  const [formState, setFormState] = useState<FormState>({
    targetingType: null,
    selectedStates: [],
    selectedCities: [],
    zipCodes: [],
    leadsPerDay: 10
  })

  const handleTargetingChange = (type: TargetingType) => {
    setFormState(prev => ({
      ...prev,
      targetingType: prev.targetingType === type ? null : type,
      selectedStates: [],
      selectedCities: [],
      zipCodes: []
    }))
  }

  const handleLeadsPerDayChange = (value: string) => {
    const numValue = parseInt(value)
    if (!isNaN(numValue) && numValue > 0) {
      setFormState(prev => ({ ...prev, leadsPerDay: numValue }))
    }
  }

  const handleZipCodesChange = (value: string) => {
    const codes = value.split('\n').filter(code => /^\d{5}$/.test(code.trim()))
    setFormState(prev => ({ ...prev, zipCodes: codes }))
  }

  const handleStateChange = (state: string) => {
    setFormState(prev => {
      if (prev.selectedStates.length >= 5 && !prev.selectedStates.includes(state)) {
        return prev
      }
      const newStates = prev.selectedStates.includes(state)
        ? prev.selectedStates.filter(s => s !== state)
        : [...prev.selectedStates, state]
      return {
        ...prev,
        selectedStates: newStates,
        selectedCities: []
      }
    })
  }

  const handleRemoveState = (stateToRemove: string) => {
    setFormState(prev => ({
      ...prev,
      selectedStates: prev.selectedStates.filter(state => state !== stateToRemove),
      selectedCities: []
    }))
  }

  const handleCityChange = (city: string) => {
    setFormState(prev => {
      if (prev.selectedCities.length >= 10 && !prev.selectedCities.includes(city)) {
        return prev
      }
      const newCities = prev.selectedCities.includes(city)
        ? prev.selectedCities.filter(c => c !== city)
        : [...prev.selectedCities, city]
      return { ...prev, selectedCities: newCities }
    })
  }

  const handleRemoveCity = (cityToRemove: string) => {
    setFormState(prev => ({
      ...prev,
      selectedCities: prev.selectedCities.filter(city => city !== cityToRemove)
    }))
  }

  const availableStates = US_STATES.filter(state => 
    !formState.selectedStates.includes(state) || 
    formState.selectedStates.length < 5
  )

  const availableCities = formState.selectedStates.length === 1
    ? MOCK_CITIES[formState.selectedStates[0]] || []
    : []

  return (
    <form onSubmit={(e) => {
      e.preventDefault()
      onSubmit(formState)
    }}>
      <Card className="w-full max-w-2xl mx-auto p-6 space-y-8">
        <div className="space-y-4">
          <h2 className="text-xl font-semibold">Do you want to target locations by:</h2>
          <div className="flex gap-8">
            <div className="flex items-center space-x-2">
              <Checkbox 
                id="national"
                checked={formState.targetingType === 'national'}
                onCheckedChange={() => handleTargetingChange('national')}
              />
              <Label htmlFor="national">National Targeting</Label>
            </div>
            <div className="flex items-center space-x-2">
              <Checkbox 
                id="state"
                checked={formState.targetingType === 'state'}
                onCheckedChange={() => handleTargetingChange('state')}
              />
              <Label htmlFor="state">State</Label>
            </div>
            <div className="flex items-center space-x-2">
              <Checkbox 
                id="zipCode"
                checked={formState.targetingType === 'zipCode'}
                onCheckedChange={() => handleTargetingChange('zipCode')}
              />
              <Label htmlFor="zipCode">Zip Code</Label>
            </div>
          </div>
        </div>

        {formState.targetingType === 'state' && (
          <div className="space-y-6">
            <div>
              <Label className="text-base font-semibold">Select By States</Label>
              {formState.selectedStates.length > 0 && (
                <div className="mt-2 mb-4">
                  <div className="flex flex-wrap gap-2">
                    {formState.selectedStates.map((state) => (
                      <button
                        key={state}
                        type="button"
                        onClick={() => handleRemoveState(state)}
                        className="bg-primary text-primary-foreground hover:bg-primary/90 px-3 py-1.5 rounded-full text-sm border flex items-center gap-1 transition-colors"
                      >
                        {state}
                        <X className="h-4 w-4" />
                      </button>
                    ))}
                  </div>
                </div>
              )}
              <div className="mt-2">
                <Select onValueChange={handleStateChange}>
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="Select State(s)" />
                  </SelectTrigger>
                  <SelectContent>
                    {availableStates.map((state) => (
                      <SelectItem key={state} value={state}>
                        {state}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <Label className="text-base font-semibold">Select By Cities</Label>
              <div className="mt-2">
                <Select 
                  onValueChange={handleCityChange} 
                  disabled={formState.selectedStates.length !== 1}
                >
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder={formState.selectedStates.length !== 1 ? "Select one state first" : "Select cities"} />
                  </SelectTrigger>
                  <SelectContent>
                    {availableCities.map((city) => (
                      <SelectItem key={city} value={city}>
                        {city}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              {formState.selectedCities.length > 0 && (
                <div className="mt-4">
                  <div className="flex flex-wrap gap-2">
                    {formState.selectedCities.map((city) => (
                      <button
                        key={city}
                        type="button"
                        onClick={() => handleRemoveCity(city)}
                        className="bg-secondary text-secondary-foreground hover:bg-secondary/90 px-3 py-1.5 rounded-full text-sm border flex items-center gap-1 transition-colors"
                      >
                        {city}
                        <X className="h-4 w-4" />
                      </button>
                    ))}
                  </div>
                </div>
              )}
              <p className="text-sm text-muted-foreground mt-1">
                * You can select up to 10 cities when exactly one state is selected.
              </p>
            </div>
          </div>
        )}

        {formState.targetingType === 'zipCode' && (
          <div className="space-y-2">
            <Label>List the zip codes that you want the campaign to target, One postal code per line:</Label>
            <Textarea
              placeholder="Enter ZIP codes (one per line)"
              className="min-h-[200px]"
              onChange={(e) => handleZipCodesChange(e.target.value)}
            />
            <p className="text-sm text-destructive">
              * A minimum of 1 valid ZIP code and a maximum of 50 valid ZIP codes must be provided.
            </p>
          </div>
        )}

        <div className="space-y-2">
          <Label htmlFor="leadsPerDay">
            Do you want to cap the amount of leads you receive per day? (Input should be numeric and greater than zero) *
          </Label>
          <div className="relative">
            <Input
              id="leadsPerDay"
              type="number"
              min="1"
              value={formState.leadsPerDay}
              onChange={(e) => handleLeadsPerDayChange(e.target.value)}
            />
            <Check className="absolute right-3 top-1/2 transform -translate-y-1/2 text-green-500 h-4 w-4" />
          </div>
        </div>

        <Button type="submit" className="w-full">Submit</Button>
      </Card>
    </form>
  )
}

