"use client"

import React, { useState, useMemo } from "react"
import { Check, X } from 'lucide-react'
import { Card } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Checkbox } from "@/components/ui/checkbox"
import { Textarea } from "@/components/ui/textarea"
import { Button } from "@/components/ui/button"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { ScrollArea } from "@/components/ui/scroll-area"

const US_STATES = [
  "Alabama", "Alaska", "Arizona", "Arkansas", "California",
  "Colorado", "Connecticut", "Delaware", "Florida", "Georgia",
  "Hawaii", "Idaho", "Illinois", "Indiana", "Iowa",
  "Kansas", "Kentucky", "Louisiana", "Maine", "Maryland",
  "Massachusetts", "Michigan", "Minnesota", "Mississippi", "Missouri",
  "Montana", "Nebraska", "Nevada", "New Hampshire", "New Jersey",
  "New Mexico", "New York", "North Carolina", "North Dakota", "Ohio",
  "Oklahoma", "Oregon", "Pennsylvania", "Rhode Island", "South Carolina",
  "South Dakota", "Tennessee", "Texas", "Utah", "Vermont",
  "Virginia", "Washington", "West Virginia", "Wisconsin", "Wyoming"
]

const generateCities = (prefix: string) => {
  return Array.from({ length: 200 }, (_, i) => `${prefix} City ${i + 1}`)
}

const MOCK_CITIES: { [key: string]: string[] } = {}
US_STATES.forEach(state => {
  MOCK_CITIES[state] = generateCities(state)
})

interface FormState {
  firstName: string
  lastName: string
  email: string
  phoneNumber: string
  targetingType: 'national' | 'state' | 'zipCode' | null
  selectedStates: string[]
  selectedCities: string[]
  zipCodes: string[]
  leadsPerDay: number
  googleSheetUrl: string
  webhookUrl: string
}

const App: React.FC = () => {
  const [formState, setFormState] = useState<FormState>({
    firstName: '',
    lastName: '',
    email: '',
    phoneNumber: '',
    targetingType: null,
    selectedStates: [],
    selectedCities: [],
    zipCodes: [],
    leadsPerDay: 10,
    googleSheetUrl: '',
    webhookUrl: ''
  })

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setFormState(prev => ({ ...prev, [name]: value }))
  }

  const handleTargetingChange = (type: 'national' | 'state' | 'zipCode') => {
    setFormState(prev => ({
      ...prev,
      targetingType: prev.targetingType === type ? null : type,
      selectedStates: [],
      selectedCities: [],
      zipCodes: []
    }))
  }

  const handleLeadsPerDayChange = (value: string) => {
    const numValue = parseInt(value)
    if (!isNaN(numValue) && numValue > 0) {
      setFormState(prev => ({ ...prev, leadsPerDay: numValue }))
    }
  }

  const handleZipCodesChange = (value: string) => {
    const codes = value.split('\n').filter(code => /^\d{5}$/.test(code.trim()))
    setFormState(prev => ({ ...prev, zipCodes: codes }))
  }

  const handleStateChange = (state: string) => {
    setFormState(prev => {
      if (prev.selectedStates.length >= 5 && !prev.selectedStates.includes(state)) {
        return prev
      }
      const newStates = prev.selectedStates.includes(state)
        ? prev.selectedStates.filter(s => s !== state)
        : [...prev.selectedStates, state]
      return {
        ...prev,
        selectedStates: newStates,
        selectedCities: []
      }
    })
  }

  const handleRemoveState = (stateToRemove: string) => {
    setFormState(prev => ({
      ...prev,
      selectedStates: prev.selectedStates.filter(state => state !== stateToRemove),
      selectedCities: []
    }))
  }

  const handleCityChange = (city: string) => {
    setFormState(prev => {
      if (prev.selectedCities.length >= 10 && !prev.selectedCities.includes(city)) {
        return prev
      }
      const newCities = prev.selectedCities.includes(city)
        ? prev.selectedCities.filter(c => c !== city)
        : [...prev.selectedCities, city]
      return { ...prev, selectedCities: newCities }
    })
  }

  const handleRemoveCity = (cityToRemove: string) => {
    setFormState(prev => ({
      ...prev,
      selectedCities: prev.selectedCities.filter(city => city !== cityToRemove)
    }))
  }

  const availableStates = useMemo(() => 
    US_STATES.filter(state => 
      !formState.selectedStates.includes(state) || 
      formState.selectedStates.length < 5
    ), [formState.selectedStates]
  )

  const availableCities = useMemo(() => 
    formState.selectedStates.length === 1
      ? MOCK_CITIES[formState.selectedStates[0]] || []
      : [],
    [formState.selectedStates]
  )

  return (
    <div className="min-h-screen bg-black">
      <form onSubmit={(e) => {
        e.preventDefault()
        console.log(formState)
      }}>
        <Card className="w-full max-w-2xl mx-auto p-6 space-y-8 bg-black/50 border-[#E4B649]/20 shadow-2xl backdrop-blur-sm">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="firstName" className="text-[#E4B649]">First Name</Label>
              <Input
                id="firstName"
                name="firstName"
                value={formState.firstName}
                onChange={handleInputChange}
                className="bg-black/50 border-[#E4B649]/20 text-white"
              />
            </div>
            <div>
              <Label htmlFor="lastName" className="text-[#E4B649]">Last Name</Label>
              <Input
                id="lastName"
                name="lastName"
                value={formState.lastName}
                onChange={handleInputChange}
                className="bg-black/50 border-[#E4B649]/20 text-white"
              />
            </div>
            <div>
              <Label htmlFor="email" className="text-[#E4B649]">E-mail</Label>
              <Input
                id="email"
                name="email"
                type="email"
                value={formState.email}
                onChange={handleInputChange}
                className="bg-black/50 border-[#E4B649]/20 text-white"
              />
            </div>
            <div>
              <Label htmlFor="phoneNumber" className="text-[#E4B649]">Phone Number</Label>
              <Input
                id="phoneNumber"
                name="phoneNumber"
                type="tel"
                value={formState.phoneNumber}
                onChange={handleInputChange}
                className="bg-black/50 border-[#E4B649]/20 text-white"
              />
            </div>
          </div>

          <div className="space-y-4">
            <h2 className="text-xl font-semibold text-[#E4B649]">Do you want to target locations by:</h2>
            <div className="flex gap-8">
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="national"
                  checked={formState.targetingType === 'national'}
                  onCheckedChange={() => handleTargetingChange('national')}
                  className="border-[#E4B649] data-[state=checked]:bg-[#E4B649] data-[state=checked]:text-black"
                />
                <Label htmlFor="national" className="text-white">National Targeting</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="state"
                  checked={formState.targetingType === 'state'}
                  onCheckedChange={() => handleTargetingChange('state')}
                  className="border-[#E4B649] data-[state=checked]:bg-[#E4B649] data-[state=checked]:text-black"
                />
                <Label htmlFor="state" className="text-white">State</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="zipCode"
                  checked={formState.targetingType === 'zipCode'}
                  onCheckedChange={() => handleTargetingChange('zipCode')}
                  className="border-[#E4B649] data-[state=checked]:bg-[#E4B649] data-[state=checked]:text-black"
                />
                <Label htmlFor="zipCode" className="text-white">Zip Code</Label>
              </div>
            </div>
          </div>

          {formState.targetingType === 'state' && (
            <div className="space-y-6">
              <div>
                <Label className="text-base font-semibold text-[#E4B649]">Select By States</Label>
                {formState.selectedStates.length > 0 && (
                  <div className="mt-2 mb-4">
                    <div className="flex flex-wrap gap-2">
                      {formState.selectedStates.map((state) => (
                        <button
                          key={state}
                          type="button"
                          onClick={() => handleRemoveState(state)}
                          className="bg-[#E4B649] text-black hover:bg-[#E4B649]/90 px-3 py-1.5 rounded-full text-sm border border-[#E4B649] flex items-center gap-1 transition-colors"
                        >
                          {state}
                          <X className="h-4 w-4" />
                        </button>
                      ))}
                    </div>
                  </div>
                )}
                <div className="mt-2">
                  <Select onValueChange={handleStateChange}>
                    <SelectTrigger className="w-full bg-black/50 border-[#E4B649]/20 text-white">
                      <SelectValue placeholder="Select State(s)" />
                    </SelectTrigger>
                    <SelectContent className="bg-black border-[#E4B649]/20">
                      {availableStates.map((state) => (
                        <SelectItem key={state} value={state} className="text-white hover:bg-[#E4B649]/20">
                          {state}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <Label className="text-base font-semibold text-[#E4B649]">Select By Cities</Label>
                <div className="mt-2">
                  <Select 
                    onValueChange={handleCityChange} 
                    disabled={formState.selectedStates.length !== 1}
                  >
                    <SelectTrigger className="w-full bg-black/50 border-[#E4B649]/20 text-white">
                      <SelectValue placeholder={formState.selectedStates.length !== 1 ? "Select one state first" : "Select cities"} />
                    </SelectTrigger>
                    <SelectContent className="bg-black border-[#E4B649]/20">
                      <ScrollArea className="h-[200px]">
                        {availableCities.map((city) => (
                          <SelectItem key={city} value={city} className="text-white hover:bg-[#E4B649]/20">
                            {city}
                          </SelectItem>
                        ))}
                      </ScrollArea>
                    </SelectContent>
                  </Select>
                </div>
                {formState.selectedCities.length > 0 && (
                  <div className="mt-4">
                    <ScrollArea className="h-[150px] w-full border border-[#E4B649]/20 rounded-md p-4 bg-black/50">
                      <div className="flex flex-wrap gap-2">
                        {formState.selectedCities.map((city) => (
                          <button
                            key={city}
                            type="button"
                            onClick={() => handleRemoveCity(city)}
                            className="bg-[#E4B649]/20 text-[#E4B649] hover:bg-[#E4B649]/30 px-3 py-1.5 rounded-full text-sm border border-[#E4B649]/20 flex items-center gap-1 transition-colors"
                          >
                            {city}
                            <X className="h-4 w-4" />
                          </button>
                        ))}
                      </div>
                    </ScrollArea>
                  </div>
                )}
                <p className="text-sm text-[#E4B649]/70 mt-1">
                  * You can select up to 10 cities from the 200 largest cities when exactly one state is selected.
                </p>
              </div>
            </div>
          )}

          {formState.targetingType === 'zipCode' && (
            <div className="space-y-2">
              <Label className="text-[#E4B649]">List the zip codes that you want the campaign to target, One postal code per line:</Label>
              <Textarea
                placeholder="Enter ZIP codes (one per line)"
                className="min-h-[200px] bg-black/50 border-[#E4B649]/20 text-white placeholder:text-[#E4B649]/50"
                onChange={(e) => handleZipCodesChange(e.target.value)}
              />
              <p className="text-sm text-[#E4B649]">
                * A minimum of 1 valid ZIP code and a maximum of 50 valid ZIP codes must be provided.
              </p>
            </div>
          )}

          <div className="space-y-2">
            <Label htmlFor="leadsPerDay" className="text-[#E4B649]">
              Do you want to cap the amount of leads you receive per day? (Input should be numeric and greater than zero) *
            </Label>
            <div className="relative">
              <Input
                id="leadsPerDay"
                type="number"
                min="1"
                value={formState.leadsPerDay}
                onChange={(e) => handleLeadsPerDayChange(e.target.value)}
                className="bg-black/50 border-[#E4B649]/20 text-white"
              />
              <Check className="absolute right-3 top-1/2 transform -translate-y-1/2 text-[#E4B649] h-4 w-4" />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="googleSheetUrl" className="text-[#E4B649]">
              Google Sheet URL
            </Label>
            <Input
              id="googleSheetUrl"
              name="googleSheetUrl"
              type="url"
              value={formState.googleSheetUrl}
              onChange={handleInputChange}
              className="bg-black/50 border-[#E4B649]/20 text-white"
              placeholder="https://docs.google.com/spreadsheets/d/..."
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="webhookUrl" className="text-[#E4B649]">
              Webhook URL
            </Label>
            <Input
              id="webhookUrl"
              name="webhookUrl"
              type="url"
              value={formState.webhookUrl}
              onChange={handleInputChange}
              className="bg-black/50 border-[#E4B649]/20 text-white"
              placeholder="https://example.com/webhook"
            />
          </div>

          <Button type="submit" className="w-full bg-[#E4B649] text-black hover:bg-[#E4B649]/90">Submit</Button>
        </Card>
      </form>
    </div>
  )
}

export default App

