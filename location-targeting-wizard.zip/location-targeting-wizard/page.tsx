import LocationTargetingForm from "./location-targeting-form"
import { FormState } from "./types/form"

export default function Page() {
  const handleSubmit = (data: FormState) => {
    console.log('Form submitted:', data)
  }

  return (
    <div className="min-h-screen bg-gray-50 p-8">
      <LocationTargetingForm onSubmit={handleSubmit} />
    </div>
  )
}

